#include <semaphore.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/shm.h>
#include<time.h>
#include <sys/wait.h>
int main(int argc,char*argv[])
{
            // shmget(): int shmget(key_t,size_tsize,intshmflg); upon successful completion, 
            // shmget() returns an identifier for the shared   memory segment.
        int key1=shmget(12328, 2048,IPC_CREAT | IPC_EXCL | 0666);
        
           //  void *shmat(int shmid ,void *shmaddr ,int shmflg);
                //  shmid is shared memory id. shmaddr specifies specific address to use but we should set
	char* buffer1= (char*) shmat(key, NULL, 0);
	
      char filename[100];
        sem_t sem;
        sem_init(&sem,1,1);
         pid_t  pid;
         pid = fork();
         if(pid==0)
         {
           FILE*fp = fopen("file1.txt","r");
              fgets(filename,10,fp);
              
              int key=shmget(12328, 2048,0);
		char* buffer1= (char*) shmat(key, NULL, 0);
		int i = 0;
		int k = 0;
	           for(i=0;i<10;i++){
		      buffer1[k] = filename[i];
		         i++;
		          k++;
		}
	}
	else
	{
	   FILE*fp = fopen("file2.txt","r");
              fgets(filename,10,fp);
	        int j = 11;
	          int i = 0;
		int k = 0;
	        for(i=0;i<10;i++){
		  buffer1[j] = filename[i];
		  i++;
		  j++;
          }
          
           pid_t  pid2;
         pid2 = fork();
         if(pid2==0)
         {
         
             int key2=shmget(12229, 2048,IPC_CREAT | IPC_EXCL | 0666);
             
             //  void *shmat(int shmid ,void *shmaddr ,int shmflg);
                //  shmid is shared memory id. shmaddr specifies specific address to use but we should set
	       char* buffer2= (char*) shmat(key, NULL, 0);
	       
	                  int key3=shmget(12329, 2048,0);
			char* buffer1= (char*) shmat(key2, NULL, 0);
			int i = 0;
		          int k = 0;
			while(buffer1[i]!=' '){
			   buffer2[k] = buffer1[i];
			   k++;
			}
			shmdt(buff2);
			shmdt(buff1);
         }
 }
	
                    
		
