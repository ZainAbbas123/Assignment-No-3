#include <semaphore.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/shm.h>
#include<time.h>
#include <sys/wait.h>

void*counting(void*something){
         int counting_of_Potential_Patients;
	counting_of_Potential_Patients =*(int *)something;
	 counting_of_Potential_Patients++;
	pthread_exit((void *) counting_of_Potential_Patients);
}

int main(int argc,char*argv[])
{
      
    int n;
    printf("Enter an integer: ");
    scanf("%d", &n); 
    printf("Number = %d",n);
  
          // A shared variable between two semapores
       int potentialCpatient = 0;
           // Create Two semaphores
        sem_t coronaPatient;
	sem_t fluPatient;
	
	   //  Initialization of Semaphores
	//    int sem_init(sem_t * sem, int pshared, unsigned int value);
	 // If pshared is 0, the semaphore is shared among all threads of a process 
	// (and hence need to be visible to all of them such as a global variable). 
	// If pshared is not zero, the semaphore is shared but should be in shared memory.
	sem_init(&coronaPatient,0,1);
	sem_init(&fluPatient,0,1);
	
	int i;
	int corona_pat_count = 0;
	int flu_pat_count = 0;
	pthread_t tid[n];
	
	int pcount=0;
	
	// loop start for creating of n threads
	for(i=0;i<n;i++)
	{
	    if(pthread_create(&tid[i], NULL,&counting,(void *)&potentialCpatient)==-1)
		{
			printf("Threads are not created \n");
		}
		pcount++;
		pthread_join(tid[i], &potentialCpatient);
	}
    //   loop ends
    
      printf("\nPrinting of Total Corona Potential patients :\n%d",potentialCpatient);
      
      
      for(int i=0;i<n;i++)
      {
           int n = rand();
	int check = n%2;			           
           if(check==1)
           {  
                   // positive report -> Patient is effected with covid-19
              corona_pat_count++;
              potentialCpatient--;
              sem_post(&coronaPatient);
              // each corona patient will go through tests and wait will be called 
              // for the coronaPatient only after two consecutive tests return false.
                           n = rand();
                           check = n%2;
			if(check==1)
			{
			     n = rand();
                           check = n%2;
				if(check==1)
				{
					sem_wait(&coronaPatient);
				}
			}	
	    }   
	    
	    else
	  {
	          // Negative report -> Patient is effected with covid-19
	         sem_post(&fluPatient);
	          flu_pat_count++;
	         potentialCpatient--;
	  }
      }
      
        printf("\n Corona patients :\n%d",corona_pat_count);
	printf("\n Flu patients:\n%d",flu_pat_count);
	
	// This destroys the semaphore *sem, so *sem becomes uninitialized.
	sem_destroy(&coronaPatient);
 	sem_destroy(&fluPatient);
	printf("\n");
	return 0;
}	
